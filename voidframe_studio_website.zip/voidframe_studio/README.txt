VOIDFRAME STUDIO — WEBSITE STARTER
==================================

Files:
- index.html      Homepage
- services.html   Services and project scope
- work.html       Concept portfolio (clearly marked as fictional demos)
- about.html      Studio positioning and process
- contact.html    Inquiry form that opens the visitor's email app
- styles.css      Shared responsive dark/futuristic styling

BEFORE PUBLISHING:
1. Open contact.html and replace REPLACE-WITH-YOUR-EMAIL@example.com with an email address you are authorized to use.
2. Replace the three fictional concept projects with your own work as you create it. Keep them labeled as concepts until they are real client projects.
3. Check every page and link on a phone and computer.
4. Do not claim client results, testimonials, or experience you do not have.
5. Agree on project scope, payment, revisions, delivery dates, and ownership in writing before accepting work.

FREE HOSTING OPTIONS:
- GitHub Pages: create a public repository, upload all files, then enable Pages in repository Settings.
- Netlify: use its manual deploy / drag-and-drop option to publish the folder or ZIP (check current free-plan terms).
- Cloudflare Pages: connect a repository and deploy the static site (check current free-plan terms).

A free host subdomain is usually provided. A custom domain generally costs money.
The contact form is mailto-based and does not store submissions. For a true hosted form, connect a form provider and review its current free tier and privacy terms.

This is a static website starter; it does not include paid hosting, a custom domain, email inbox, analytics, or payment processing.
